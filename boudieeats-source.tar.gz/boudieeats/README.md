# boudieeats.

An Arabic-first Egyptian food journal. The project builds to static files with Astro and TypeScript. Search, filtering, cooking mode and bookmarks run in the browser.

## Run it locally

Use Node.js 22.12 or later. Run these commands from this folder.

```sh
npm ci
npm run dev
```

Open the local address printed by Astro. Use these commands to check the project and preview a production build.

```sh
npm run check
npm run build
npm run preview
```

## Publish and maintain the journal

- `src/content/recipes/` contains recipe entries. Copy the format in `shaareya-bel-laban.md`. Each file's name becomes its URL slug. Set `preview: true` for photo previews. Remove that flag and supply `ingredients` and `steps` to publish a complete recipe.
- `src/content/reviews/` accepts `kind: restaurant` with a `restaurant` name or `kind: taste` with a `product` name. Add the actual notes as Markdown after the frontmatter. For restaurants, record only the dates, prices, dishes and ratings you can verify. Each optional rating stands on its own out of 10.
- `src/content/stories/` accepts Markdown stories with `title`, `description` and body. Optional fields include `author`, `date` (YYYY-MM-DD), `categories`, `readingMinutes`, `hero`, `gallery`, `pullQuote` and `related`. The first published file automatically appears on the archive.
- Set `draft: true` to keep an entry out of the site, search and sitemap. Set `featured` to surface a recipe and `pick` to include an entry in Boudie's picks. List other slugs from the same collection under `related`.
- Edit the bio and brand copy in `src/lib/site.ts` and the About page in `src/pages/about.astro`. The full field definitions are in `src/content.config.ts`. The publishing layer can later be replaced with a headless CMS loader.

### Media

Place finished web assets in `public/media/`. If possible, supply 520px and 1100px-wide WebPs in `sizes`, with the real width of each asset. Each image needs descriptive `alt` text and its intrinsic `width` and `height`. Provide authentic photos for each dish and use captions for context. The cover is the supplied baked variation of recipe #001. The steak entry uses the JPEG, both converted DNGs and the supplied short cooking clip. Image exports and MP4 are resized for the web with embedded capture and location metadata removed.

Set a recipe's `video.src` to an H.264 MP4 and add a poster with still-frame dimensions and alt text. Add an Arabic WebVTT file to `video.captions` when available. Use `gallery`, step `image`, and `variation.image` for the corresponding photos. The included video is the steak clip. Insert the vermicelli footage and its poster via recipe #001's frontmatter when supplied.

For exact serving adjustments, add a numeric `servings` value and reliable numeric `amount` plus `unit` values to every ingredient. Recipe #001 intentionally uses flexible quantities. The ingredient ticks last within a browser tab, and bookmarks persist across visits on the same browser when local storage is available.

## Deploy

Copy `.env.example` to `.env` for local settings or set the variables in your host's build environment. Use `SITE_URL` for your live origin and set `PUBLIC_INDEXABLE=true` only for a public launch. Canonicals and the sitemap use the configured origin. The private deployment uses `noindex`.

- **Cloudflare Pages** — Use `npm run build` as the build command and `dist` as the output directory. Alternatively, upload the built `dist` directory as a static deployment. The file at `public/_headers` defines cache headers for images and compiled assets.
- **GitHub Pages** — Build with `SITE_URL=https://YOUR-NAME.github.io` and `SITE_BASE_PATH=/YOUR-REPOSITORY/` for a repository site. Publish `dist` using GitHub Pages' upload and deployment workflow. Use `SITE_BASE_PATH=/` for a site at the origin root and set `SITE_URL` to that origin.
- **Sites** — The static output is declared in `.openai/hosting.json` for the original private deployment.

Contact and newsletter accept optional HTTPS form action URLs through `PUBLIC_CONTACT_ACTION` and `PUBLIC_NEWSLETTER_ACTION`. Use receiving services that accept HTML POSTs and show their own confirmation or error page. Contact submits `name`, `email`, `topic` and `message`. Newsletter submits `email`. Rebuild after setting or changing a URL. Until configured, both sections show a closed state. Privacy-conscious analytics such as host-provided analytics can be enabled through the host or loaded centrally from `src/layouts/Base.astro`.

## Design system

The design lives in `src/styles/global.css` and the shared components under `src/components/`. Tahini Cream `#FFF7EB` is the paper. Hibiscus Burgundy `#51283E` anchors the masthead, display type and footer. Tomato Red `#C94D42` is the action accent with a darker companion for small reverse text. Molokhia Green `#527658` identifies recipes and Saffron Gold `#F2BC5D` marks picks and highlights. Ink `#282427` is the reading color.

Aref Ruqaa is the Arabic display face. Lalezar is the Arabic reading and UI face. Fraunces draws the lowercase wordmark and DM Sans sets Latin labels and metadata. The favicon is the lowercase b monogram. Fonts are served locally.

The homepage uses a split editorial cover, headline, issue line, and a wax-stamp treatment for «أكيل.». Recipes share archive cards, a numbered method, a sticky desktop checklist, «تركات بودي» and a separate gold variation panel. The editorial layout handles stories, restaurant reviews and taste tests. Images collapse into a single reading column on phones. Keyboard focus, reduced motion, and a dedicated print layout are defined alongside the component styles.

import { defineConfig } from 'astro/config';
import { loadEnv } from 'vite';

const env = { ...loadEnv(process.env.NODE_ENV ?? 'production', process.cwd(), ''), ...process.env };
const site = env.SITE_URL || undefined;

export default defineConfig({
  site,
  base: env.SITE_BASE_PATH || '/',
  trailingSlash: 'always',
  output: 'static',
  devToolbar: { enabled: false },
  build: { format: 'directory' },
});

import { getCollection, type CollectionEntry } from 'astro:content';
import { pathFor, type Section } from './site';

export type EditorialEntry = CollectionEntry<Section>;

export async function published<C extends Section>(section: C) {
  const entries = await getCollection(section, ({ data }) => !data.draft);
  return entries.sort((a, b) => {
    const byDate = (b.data.date ?? '').localeCompare(a.data.date ?? '');
    if (byDate) return byDate;
    if ('number' in a.data && 'number' in b.data) return a.data.number - b.data.number;
    return a.id.localeCompare(b.id);
  });
}

export async function allPublished() {
  const collections = await Promise.all([published('recipes'), published('reviews'), published('stories')]);
  return collections.flat();
}

export function entryHref(entry: EditorialEntry) {
  return pathFor(`/${entry.collection}/${entry.id}/`);
}

export function entryTitle(entry: EditorialEntry) {
  return entry.collection === 'recipes' ? entry.data.shortTitle ?? entry.data.title : entry.data.title;
}

export function recipeNumber(number: number) {
  return String(number).padStart(3, '0');
}

export function relatedEntries<C extends Section>(entries: CollectionEntry<C>[], current: CollectionEntry<C>) {
  const related = current.data.related.map((id) => entries.find((entry) => entry.id === id)).filter((entry) => entry !== undefined && entry.id !== current.id);
  return [...new Set([...related, ...entries.filter((entry) => entry.id !== current.id)])].slice(0, 3);
}

export function searchTerms(entry: EditorialEntry) {
  const { data } = entry;
  const terms = [data.title, data.description, data.author, ...data.categories, ...data.tags, entry.id];
  if (entry.collection === 'recipes') {
    terms.push(entry.data.shortTitle ?? '', entry.data.englishTitle ?? '', entry.data.difficulty ?? '', ...entry.data.ingredients.map((item) => item.text));
  }
  if (entry.collection === 'reviews') terms.push(entry.data.restaurant ?? '', entry.data.product ?? '', entry.data.location ?? '', entry.data.cuisine ?? '', ...entry.data.dishes);
  return terms.join(' ');
}

export const brand = {
  name: 'boudieeats.',
  descriptor: 'An Egyptian food journal.',
  signature: 'أكيل.',
  philosophy: 'مش كل حاجة بالمقادير… في حاجات بالمزاج.',
  english: 'Egyptian appetite. Unfiltered opinions.',
  description: 'يومية أكل مصرية مع بودي. وصفات من المطبخ، تجارب مطاعم، وحكايات عن الأكل اللي بنحبه.',
  about: 'أنا بودي، بحب الأكل وبحب أفهمه. بكتب عن اللي بجربه في المطبخ، واللي بطلبه بره، والحكايات اللي بتفضل معانا بعد ما الأكل يخلص.',
};
export const sections = {
  recipes: { name: 'الوصفات', english: 'Recipes' },
  reviews: { name: 'التجارب', english: 'Reviews' },
  stories: { name: 'حكايات أكل', english: 'Food stories' },
};
export type Section = keyof typeof sections;

export const navigation = [
  { title: 'الرئيسية', path: '/' },
  { title: 'الوصفات', path: '/recipes/' },
  { title: 'التجارب', path: '/reviews/' },
  { title: 'حكايات أكل', path: '/stories/' },
  { title: 'عن بودي', path: '/about/' },
];

export function pathFor(path: string) {
  const base = import.meta.env.BASE_URL.replace(/\/$/, '');
  return path.startsWith('/') && !path.startsWith('//') ? base + path : path;
}

export function formAction(raw: string | undefined) {
  if (!raw) return;
  try {
    const url = new URL(raw);
    if (url.protocol === 'https:' && !url.username && !url.password) return url.href;
  } catch {
    return;
  }
}

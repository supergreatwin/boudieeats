const share = document.querySelector<HTMLButtonElement>('[data-share]');
const printButton = document.querySelector<HTMLButtonElement>('[data-print]');
const shareStatus = document.querySelector<HTMLElement>('[data-action-message]');
const copyPanel = document.querySelector<HTMLElement>('[data-copy-panel]');
const copyValue = document.querySelector<HTMLInputElement>('[data-copy-value]');

if (printButton) {
  printButton.hidden = false;
  printButton.addEventListener('click', () => window.print());
}
if (share) {
  share.hidden = false;
  share.addEventListener('click', async () => {
    const url = new URL(location.href);
    url.hash = '';
    url.search = '';
    const payload = { title: share.dataset.share, url: url.href };
    if (navigator.share && (!navigator.canShare || navigator.canShare(payload))) {
      try {
        await navigator.share(payload);
        return;
      } catch (error) {
        if (error instanceof DOMException && error.name === 'AbortError') return;
      }
    }
    try {
      await navigator.clipboard.writeText(url.href);
      if (shareStatus) shareStatus.textContent = 'الرابط اتنسخ.';
    } catch {
      if (copyPanel && copyValue) {
        copyPanel.hidden = false;
        copyValue.value = url.href;
        copyValue.focus();
        copyValue.select();
      }
    }
  });
}
document.querySelector('[data-copy-close]')?.addEventListener('click', () => {
  if (copyPanel) copyPanel.hidden = true;
  share?.focus();
});

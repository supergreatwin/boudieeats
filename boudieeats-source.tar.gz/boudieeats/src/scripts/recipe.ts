const recipe = document.querySelector<HTMLElement>('[data-recipe]');
if (recipe) {
  const key = `boudieeats.ingredients.${recipe.dataset.recipe}`;
  const checks = [...recipe.querySelectorAll<HTMLInputElement>('[data-ingredient]')];
  const count = recipe.querySelector<HTMLElement>('[data-ingredient-count]');
  const reset = recipe.querySelector<HTMLButtonElement>('[data-ingredients-reset]');
  const cooking = recipe.querySelector<HTMLButtonElement>('[data-cook-mode]');
  const status = recipe.querySelector<HTMLElement>('[data-action-message]');
  let wake: WakeLockSentinel | undefined;
  let pendingWake = false;
  let saved: string[] = [];
  try {
    const value: unknown = JSON.parse(sessionStorage.getItem(key) ?? '[]');
    if (Array.isArray(value)) saved = value.filter((item): item is string => typeof item === 'string');
  } catch { /* Checkmarks still work in this view. */ }
  for (const checkbox of checks) checkbox.checked = saved.includes(checkbox.dataset.ingredient ?? '');

  function updateChecklist() {
    const completed = checks.filter((checkbox) => checkbox.checked);
    if (count) {
      count.hidden = false;
      count.textContent = `${completed.length} / ${checks.length}`;
      count.setAttribute('aria-label', `${completed.length} من ${checks.length} مكونات جاهزة`);
    }
    if (reset) reset.hidden = completed.length === 0;
    try {
      sessionStorage.setItem(key, JSON.stringify(completed.map((checkbox) => checkbox.dataset.ingredient)));
    } catch { /* The current checkmarks remain usable. */ }
  }
  checks.forEach((checkbox) => checkbox.addEventListener('change', updateChecklist));
  reset?.addEventListener('click', () => {
    checks.forEach((checkbox) => { checkbox.checked = false; });
    updateChecklist();
    checks[0]?.focus();
  });
  updateChecklist();

  async function syncWakeLock() {
    if (!recipe?.classList.contains('cooking-mode') || document.hidden) {
      await wake?.release().catch(() => undefined);
      wake = undefined;
      return;
    }
    if (!('wakeLock' in navigator) || wake || pendingWake) return;
    pendingWake = true;
    try {
      const lock = await navigator.wakeLock.request('screen');
      if (!recipe.classList.contains('cooking-mode') || document.hidden) {
        await lock.release();
      } else {
        wake = lock;
        lock.addEventListener('release', () => { if (wake === lock) wake = undefined; }, { once: true });
      }
    } catch { /* Enlarged instructions still work when wake lock is unavailable. */ }
    finally { pendingWake = false; }
  }
  if (cooking) {
    cooking.hidden = false;
    cooking.addEventListener('click', () => {
      const active = recipe.classList.toggle('cooking-mode');
      cooking.setAttribute('aria-pressed', String(active));
      if (status) status.textContent = active ? 'وضع الطبخ شغّال. الخط بقى أكبر.' : 'رجعت للعرض العادي.';
      void syncWakeLock();
    });
    document.addEventListener('visibilitychange', () => void syncWakeLock());
  }

  const servings = recipe.querySelector<HTMLInputElement>('[data-servings]');
  const servingsUI = recipe.querySelector<HTMLElement>('[data-servings-ui]');
  if (servings && servingsUI) {
    servingsUI.hidden = false;
    const base = Number(servings.dataset.servings);
    const quantities = recipe.querySelectorAll<HTMLElement>('[data-amount]');
    const formatter = new Intl.NumberFormat('ar-EG', { maximumFractionDigits: 3 });
    servings.addEventListener('input', () => {
      if (!servings.validity.valid || !servings.valueAsNumber) return;
      for (const quantity of quantities) {
        quantity.textContent = formatter.format(Number(quantity.dataset.amount) * servings.valueAsNumber / base) + ' ';
      }
    });
  }
}

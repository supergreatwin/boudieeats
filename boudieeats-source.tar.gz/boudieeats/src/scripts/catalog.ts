import { readSaved } from './saved';

function normalize(value: string) {
  return value.toLocaleLowerCase().normalize('NFKC')
    .replace(/[\u0610-\u061a\u064b-\u065f\u0670\u0640]/g, '')
    .replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه')
    .replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
}

const catalog = document.querySelector<HTMLElement>('[data-catalog]');
if (catalog) {
  const form = catalog.querySelector<HTMLFormElement>('[data-filters]');
  const list = catalog.querySelector<HTMLElement>('[data-entry-list]');
  const status = catalog.querySelector<HTMLElement>('[data-results-status]');
  const empty = catalog.querySelector<HTMLElement>('[data-catalog-empty]');
  const reset = catalog.querySelector<HTMLButtonElement>('button[type="reset"]');
  const entries = Array.from(catalog.querySelectorAll<HTMLElement>('[data-entry]')).map((node) => ({
    node,
    terms: normalize(node.dataset.terms ?? ''),
    categories: JSON.parse(node.dataset.categories ?? '[]') as string[],
    time: Number(node.dataset.minutes || '0'),
    difficulty: node.dataset.difficulty ?? 'unknown',
    section: node.dataset.section ?? '',
    href: node.dataset.href ?? '',
    title: node.dataset.title ?? '',
  }));

  function update(syncUrl = false) {
    const data = new FormData(form ?? undefined);
    const query = normalize(String(data.get('q') ?? '')).split(' ').filter(Boolean);
    const category = String(data.get('category') ?? '');
    const time = String(data.get('time') ?? '');
    const difficulty = String(data.get('difficulty') ?? '');
    const section = String(data.get('section') ?? '');
    const sort = String(data.get('sort') ?? '');
    const saved = catalog?.dataset.catalog === 'saved' ? new Set(readSaved()) : undefined;
    let count = 0;

    for (const entry of entries) {
      const timeBand = !entry.time ? 'unknown' : entry.time <= 15 ? 'under15' : entry.time <= 30 ? '16to30' : 'over30';
      const match = saved ? saved.has(entry.href) :
        query.every((term) => entry.terms.includes(term)) &&
        (!category || entry.categories.includes(category)) && (!time || timeBand === time) &&
        (!difficulty || entry.difficulty === difficulty) && (!section || entry.section === section);
      entry.node.hidden = !match;
      if (match) count++;
    }

    if (list) {
      list.hidden = count === 0;
      const sorted = [...entries];
      if (sort === 'title') sorted.sort((a, b) => a.title.localeCompare(b.title, 'ar'));
      if (sort === 'time') sorted.sort((a, b) => (a.time || Infinity) - (b.time || Infinity));
      if (form?.elements.namedItem('sort')) list.append(...sorted.map((entry) => entry.node));
    }
    if (status) status.textContent = count ? `النتائج: ${new Intl.NumberFormat('ar-EG').format(count)}` : '';
    if (empty) empty.hidden = count !== 0;
    if (reset) reset.hidden = ![...data.values()].some(Boolean);
    if (syncUrl) {
      const url = new URL(location.href);
      for (const [name, value] of data) {
        if (value) url.searchParams.set(name, String(value));
        else url.searchParams.delete(name);
      }
      history.replaceState(null, '', url);
    }
  }

  if (form) {
    const params = new URLSearchParams(location.search);
    for (const control of form.elements) {
      if (control instanceof HTMLInputElement || control instanceof HTMLSelectElement) {
        const value = params.get(control.name);
        if (value !== null && (!(control instanceof HTMLSelectElement) || [...control.options].some((option) => option.value === value))) control.value = value;
      }
    }
    form.addEventListener('input', () => update(true));
    form.addEventListener('reset', (event) => {
      event.preventDefault();
      for (const control of form.elements) {
        if (control instanceof HTMLInputElement || control instanceof HTMLSelectElement) control.value = '';
      }
      update(true);
    });
    form.addEventListener('submit', (event) => { event.preventDefault(); update(true); });
  } else {
    document.addEventListener('boudie:saved', () => {
      const active = document.activeElement;
      update();
      if (active instanceof HTMLElement && active.closest('[hidden]')) {
        const next = list?.querySelector<HTMLElement>('[data-entry]:not([hidden]) a');
        if (next) next.focus();
        else if (empty) { empty.tabIndex = -1; empty.focus(); }
      }
    });
  }
  update();
}

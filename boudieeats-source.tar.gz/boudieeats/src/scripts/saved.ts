const key = 'boudieeats.saved.v1';
let fallback: string[] = [];
let memoryOnly = false;

export function readSaved(): string[] {
  if (memoryOnly) return fallback;
  try {
    const items: unknown = JSON.parse(localStorage.getItem(key) ?? '[]');
    return Array.isArray(items) ? items.filter((item): item is string => typeof item === 'string') : [];
  } catch {
    return fallback;
  }
}

function writeSaved(items: string[]) {
  fallback = items;
  try {
    localStorage.setItem(key, JSON.stringify(items));
  } catch {
    memoryOnly = true;
  }
  document.dispatchEvent(new Event('boudie:saved'));
}

function updateSavedControls() {
  const saved = readSaved();
  for (const control of document.querySelectorAll<HTMLButtonElement>('[data-save]')) {
    const active = saved.includes(control.dataset.save ?? '');
    control.hidden = false;
    control.setAttribute('aria-pressed', String(active));
    const label = control.querySelector('[data-save-label]');
    if (label) label.textContent = active ? 'محفوظة' : 'احفظ';
  }
  const count = document.querySelector<HTMLElement>('[data-saved-count]');
  if (count) {
    count.hidden = saved.length === 0;
    count.textContent = String(saved.length);
  }
}

document.addEventListener('click', (event) => {
  if (!(event.target instanceof Element)) return;
  const button = event.target.closest<HTMLButtonElement>('button[data-save]');
  const url = button?.dataset.save;
  if (!url) return;
  const items = readSaved();
  const isSaved = items.includes(url);
  writeSaved(isSaved ? items.filter((item) => item !== url) : [...items, url]);
  const status = document.querySelector('[data-action-message]');
  if (status) status.textContent = memoryOnly
    ? 'الحفظ متاح لحد ما تقفل الصفحة.'
    : isSaved ? 'اتشالت من المحفوظات.' : 'اتحفظت على الجهاز ده.';
});
document.addEventListener('boudie:saved', updateSavedControls);
window.addEventListener('storage', (event) => {
  if (event.key === key || event.key === null) document.dispatchEvent(new Event('boudie:saved'));
});
updateSavedControls();

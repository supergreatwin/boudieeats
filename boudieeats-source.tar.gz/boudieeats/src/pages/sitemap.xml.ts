import type { APIRoute } from 'astro';
import { allPublished, entryHref } from '../lib/content';
import { pathFor } from '../lib/site';

const escapeXML = (value: string) => value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

export const GET: APIRoute = async ({ site }) => {
  const entries = await allPublished();
  const routes = ['/', '/recipes/', '/reviews/', '/stories/', '/about/', '/contact/'];
  const urls = [...routes.map((route) => ({ href: pathFor(route), date: undefined })),
    ...entries.map((entry) => ({ href: entryHref(entry), date: entry.data.date }))];
  const nodes = site ? urls.map(({ href, date }) => `<url><loc>${escapeXML(new URL(href, site).href)}</loc>${date ? `<lastmod>${date}</lastmod>` : ''}</url>`).join('') : '';
  return new Response(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${nodes}</urlset>`,
    { headers: { 'Content-Type': 'application/xml; charset=utf-8' } });
};

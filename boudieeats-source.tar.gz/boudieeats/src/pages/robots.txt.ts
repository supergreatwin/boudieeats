import type { APIRoute } from 'astro';
import { pathFor } from '../lib/site';

export const GET: APIRoute = ({ site }) => {
  const canIndex = import.meta.env.PUBLIC_INDEXABLE === 'true' && site;
  const text = canIndex
    ? `User-agent: *\nAllow: /\nSitemap: ${new URL(pathFor('/sitemap.xml'), site).href}\n`
    : 'User-agent: *\nDisallow: /\n';
  return new Response(text, { headers: { 'Content-Type': 'text/plain; charset=utf-8' } });
};

---
number: 2
preview: true
title: "ستيك متحمّر"
englishTitle: "Seared steak"
description: "ستيك من مطبخ بودي، من الطاسة لحد التقطيع."
categories: ["أكل بيتي"]
tags: ["لحمة", "ستيك", "طاسة", "ستيك متحمر"]
hero: {"src": "/media/steak.webp", "alt": "قطعة ستيك متحمّرة على طبق أبيض", "width": 1100, "height": 1467, "sizes": [{"src": "/media/steak-small.webp", "width": 520}, {"src": "/media/steak.webp", "width": 1100}]}
gallery: [{"src": "/media/steak-stove.webp", "alt": "ستيك متحمّر في طبق وردي جنب طاسة على البوتاجاز", "width": 1100, "height": 1467, "sizes": [{"src": "/media/steak-stove-small.webp", "width": 520}, {"src": "/media/steak-stove.webp", "width": 1100}], "caption": "بعد التحمير"}, {"src": "/media/steak-sliced.webp", "alt": "شرائح ستيك في طبق وردي بعد التقطيع", "width": 1100, "height": 1467, "sizes": [{"src": "/media/steak-sliced-small.webp", "width": 520}, {"src": "/media/steak-sliced.webp", "width": 1100}], "caption": "بعد التقطيع"}]
video: {"src": "/media/steak-pan.mp4", "width": 720, "height": 1280, "poster": {"src": "/media/steak-video.webp", "alt": "قطعتين ستيك في الطاسة", "width": 540, "height": 960}}
---

لقطات للستيك من الطاسة، وبعد التحمير والتقطيع.

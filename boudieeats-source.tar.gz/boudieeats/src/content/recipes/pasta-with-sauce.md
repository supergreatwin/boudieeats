---
number: 3
preview: true
title: "مكرونة بالصوص"
englishTitle: "Pasta with sauce"
description: "طبق مكرونة من مطبخ بودي، بصوص لونه برتقاني."
categories: ["أكل بيتي"]
tags: ["مكرونة", "باستا", "صوص"]
hero: {"src": "/media/pasta.webp", "alt": "مكرونة بصوص برتقاني في طبق أزرق منقوش جنب مشروب بتلج", "width": 1100, "height": 1467, "sizes": [{"src": "/media/pasta-small.webp", "width": 520}, {"src": "/media/pasta.webp", "width": 1100}]}
---

مكرونة بالصوص في طبق أزرق، وجنبها مشروب ساقع بتلج.

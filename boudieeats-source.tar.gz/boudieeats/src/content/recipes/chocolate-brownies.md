---
number: 5
preview: true
title: "براونيز بالشوكولاتة"
englishTitle: "Chocolate Brownies"
description: "براونيز بالشوكولاتة متقطّعة مربعات."
categories: ["حلويات"]
tags: ["براونيز","شوكولاتة","brownies"]
hero: {"src":"/media/chocolate-brownies.webp","alt":"مربعات براونيز بالشوكولاتة في علبة شفافة","width":768,"height":1024,"sizes":[{"src":"/media/chocolate-brownies-small.webp","width":520},{"src":"/media/chocolate-brownies.webp","width":768}]}
related: ["skillet-chocolate-cookie"]
---

مربعات براونيز من مطبخ بودي.

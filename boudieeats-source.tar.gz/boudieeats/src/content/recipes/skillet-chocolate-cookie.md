---
number: 6
preview: true
title: "كوكيز شوكولاتة في الطاسة"
englishTitle: "Skillet Chocolate Cookie"
description: "كوكيز كبيرة بقطع شوكولاتة في طاسة صغيرة."
categories: ["حلويات"]
tags: ["كوكيز","شوكولاتة","طاسة","cookie","skillet"]
hero: {"src":"/media/skillet-chocolate-cookie.webp","alt":"كوكيز كبيرة بقطع شوكولاتة في طاسة صغيرة","width":768,"height":1024,"sizes":[{"src":"/media/skillet-chocolate-cookie-small.webp","width":520},{"src":"/media/skillet-chocolate-cookie.webp","width":768}]}
related: ["chocolate-brownies"]
---

كوكيز واحدة كبيرة، وقطع الشوكولاتة باينة على الوش.

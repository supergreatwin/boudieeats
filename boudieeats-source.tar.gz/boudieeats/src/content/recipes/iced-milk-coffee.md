---
number: 4
preview: true
title: "قهوة ساقعة باللبن"
englishTitle: "Iced milk coffee"
description: "قهوة ساقعة باللبن والتلج من مطبخ بودي."
categories: ["مشروبات"]
tags: ["قهوة", "آيس كوفي", "لبن", "تلج"]
hero: {"src": "/media/iced-coffee.webp", "alt": "كوباية زجاج فيها طبقات قهوة ولبن وتلج", "width": 1100, "height": 1467, "sizes": [{"src": "/media/iced-coffee-small.webp", "width": 520}, {"src": "/media/iced-coffee.webp", "width": 1100}]}
---

قهوة ساقعة في كوباية زجاج، واللبن لسه بيختلط بالقهوة.

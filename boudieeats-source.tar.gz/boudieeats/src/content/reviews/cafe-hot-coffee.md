---
kind: "restaurant"
preview: true
title: "فنجان قهوة في الكافيه"
description: "رسمة على وش القهوة ولقطة للقعدة من جوّه."
categories: ["صور من التجارب"]
tags: ["قهوة","كافيه","رغوة اللبن","coffee"]
hero: {"src":"/media/cafe-coffee.webp","alt":"فنجان قهوة برسمة قلب من رغوة اللبن","width":768,"height":1024,"sizes":[{"src":"/media/cafe-coffee-small.webp","width":520},{"src":"/media/cafe-coffee.webp","width":768}]}
gallery: [{"src":"/media/cafe-coffee-table.webp","alt":"فنجان قهوة برسمة على الوش جنب اللابتوب","width":768,"height":1024,"sizes":[{"src":"/media/cafe-coffee-table-small.webp","width":520},{"src":"/media/cafe-coffee-table.webp","width":768}],"caption":"الفنجان على الترابيزة"},{"src":"/media/cafe-interior.webp","alt":"قعدة الكافيه بإضاءة دافية ولابتوب على الترابيزة","width":768,"height":1024,"sizes":[{"src":"/media/cafe-interior-small.webp","width":520},{"src":"/media/cafe-interior.webp","width":768}],"caption":"القعدة من جوّه"}]
---

---
kind: "taste"
title: "جمبري بحري"
product: "Bahary by Seaside Shrimp"
description: "كيس جمبري من بحري في قسم اختبار الطعم."
categories: ["اختبار الطعم"]
tags: ["جمبري","بحري","سي سايد","bahary","shrimp"]
hero: {"src":"/media/bahary-shrimp.webp","alt":"كيس جمبري بحري وعليه ملصق أزرق","width":768,"height":1024,"sizes":[{"src":"/media/bahary-shrimp-small.webp","width":520},{"src":"/media/bahary-shrimp.webp","width":768}]}
---

---
kind: "restaurant"
preview: true
title: "قهوة ساقعة جنب الشباك"
description: "كوباية قهوة بتلج جنب كيس أصفر على الترابيزة."
categories: ["صور من التجارب"]
tags: ["قهوة","آيس كوفي","كافيه","iced coffee"]
hero: {"src":"/media/cafe-iced-coffee.webp","alt":"كوباية قهوة ساقعة جنب كيس أصفر على ترابيزة عند الشباك","width":768,"height":1024,"sizes":[{"src":"/media/cafe-iced-coffee-small.webp","width":520},{"src":"/media/cafe-iced-coffee.webp","width":768}]}
---

---
kind: "restaurant"
preview: true
title: "تيك أواي في العربية"
description: "صورتين للطلب بعد ما اتفتح في العربية."
categories: ["صور من التجارب"]
tags: ["تيك أواي","أكل جاهز","takeaway"]
hero: {"src":"/media/takeaway-spoon.webp","alt":"معلقة بيضا فوق علبة أكل تيك أواي وعليها طبقة زيت","width":768,"height":1024,"sizes":[{"src":"/media/takeaway-spoon-small.webp","width":520},{"src":"/media/takeaway-spoon.webp","width":768}]}
gallery: [{"src":"/media/takeaway-bowl.webp","alt":"علبة أكل تيك أواي مفتوحة بمعلقة جوه العربية","width":768,"height":1024,"sizes":[{"src":"/media/takeaway-bowl-small.webp","width":520},{"src":"/media/takeaway-bowl.webp","width":768}]}]
---

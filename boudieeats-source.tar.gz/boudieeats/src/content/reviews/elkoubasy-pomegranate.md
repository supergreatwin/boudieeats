---
kind: "taste"
product: "Elkoubasy Pomegranate Juice"
title: "عصير رمان الكبيسي"
description: "عصير الرمان من الكبيسي في قسم اختبار الطعم."
categories: ["اختبار الطعم"]
tags: ["عصير", "رمان", "الكبيسي", "elkoubasy", "pomegranate"]
hero: {"src": "/media/taste-pomegranate.webp", "alt": "زجاجة عصير رمان الكبيسي", "width": 768, "height": 1024, "sizes": [{"src": "/media/taste-pomegranate-small.webp", "width": 520}, {"src": "/media/taste-pomegranate.webp", "width": 768}]}
---



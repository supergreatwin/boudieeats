---
kind: "taste"
title: "تونة كافا"
product: "Cava Canned Tuna"
description: "تونة كافا المعلبة في قسم اختبار الطعم."
categories: ["اختبار الطعم"]
tags: ["تونة","كافا","cava","tuna"]
hero: {"src":"/media/cava-tuna.webp","alt":"علبة تونة كافا قدام رف التونة في السوبرماركت","width":768,"height":1024,"sizes":[{"src":"/media/cava-tuna-small.webp","width":520},{"src":"/media/cava-tuna.webp","width":768}]}
---

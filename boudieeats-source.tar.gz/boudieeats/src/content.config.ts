import { defineCollection } from 'astro:content';
import { glob } from 'astro/loaders';
import { z } from 'astro/zod';

const media = z.object({
  src: z.string().min(1),
  alt: z.string().min(1),
  width: z.number().int().positive(),
  height: z.number().int().positive(),
  sizes: z.array(z.object({ src: z.string(), width: z.number().int().positive() })).optional(),
  caption: z.string().optional(),
});

const common = {
  title: z.string(),
  description: z.string(),
  author: z.string().default('بودي'),
  date: z.iso.date().optional(),
  categories: z.array(z.string()).default([]),
  tags: z.array(z.string()).default([]),
  hero: media.optional(),
  featured: z.boolean().default(false),
  pick: z.boolean().default(false),
  draft: z.boolean().default(false),
  related: z.array(z.string()).default([]),
  seo: z.object({ title: z.string().optional(), description: z.string().optional(), image: z.string().optional() }).optional(),
};

const score = z.number().min(0).max(10).optional();
const recipes = defineCollection({
  loader: glob({ base: './src/content/recipes', pattern: '*.md' }),
  schema: z.object({
    ...common,
    number: z.number().int().positive(),
    preview: z.boolean().default(false),
    shortTitle: z.string().optional(),
    englishTitle: z.string().optional(),
    headline: z.string().optional(),
    coverIntro: z.string().optional(),
    difficulty: z.enum(['سهلة', 'متوسطة', 'محتاجة تمرين']).optional(),
    prepMinutes: z.number().int().positive().optional(),
    cookMinutes: z.number().int().positive().optional(),
    servings: z.number().int().positive().optional(),
    gallery: z.array(media).default([]),
    video: z.object({
      src: z.string(), poster: media, captions: z.string().optional(),
      width: z.number().int().positive().default(540),
      height: z.number().int().positive().default(960),
    }).optional(),
    ingredients: z.array(z.object({
      text: z.string(),
      amount: z.number().positive().optional(),
      unit: z.string().optional(),
    })).default([]),
    steps: z.array(z.object({ title: z.string(), body: z.array(z.string()).min(1), image: media.optional() })).default([]),
    tips: z.array(z.object({ title: z.string(), text: z.string() })).default([]),
    variation: z.object({ title: z.string(), steps: z.array(z.string()), image: media.optional() }).optional(),
  }).refine((recipe) => recipe.preview || (recipe.ingredients.length && recipe.steps.length),
    'A complete recipe needs ingredients and steps. For photo previews, set preview: true.'),
});
const reviews = defineCollection({
  loader: glob({ base: './src/content/reviews', pattern: '*.md' }),
  schema: z.object({
    ...common,
    kind: z.enum(['restaurant', 'taste']).default('restaurant'),
    preview: z.boolean().default(false),
    restaurant: z.string().optional(),
    product: z.string().optional(),
    location: z.string().optional(),
    cuisine: z.string().optional(),
    visitDate: z.iso.date().optional(),
    visitContext: z.string().optional(),
    price: z.string().optional(),
    dishes: z.array(z.string()).default([]),
    ratings: z.object({ taste: score, value: score, service: score, atmosphere: score }).optional(),
    verdict: z.string().optional(),
    best: z.string().optional(),
    weakest: z.string().optional(),
    gallery: z.array(media).default([]),
  }).refine((review) => review.kind === 'taste'
    ? Boolean(review.product)
    : Boolean(review.restaurant || (review.preview && review.hero)),
    'Add a product for a taste test, a name for a restaurant review, or a cover image for an unnamed photo preview.'),
});
const stories = defineCollection({
  loader: glob({ base: './src/content/stories', pattern: '*.md' }),
  schema: z.object({
    ...common,
    readingMinutes: z.number().int().positive().optional(),
    pullQuote: z.string().optional(),
    gallery: z.array(media).default([]),
  }),
});

export const collections = { recipes, reviews, stories };
